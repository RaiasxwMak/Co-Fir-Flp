const canvas = document.getElementById('fireworksCanvas');
const ctx = canvas.getContext('2d');

// Устанавливаем размер canvas на весь экран
canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

// Массив для хранения частиц фейерверка
let particles = [];

// Класс для создания частиц
class Particle {
    constructor(x, y, color) {
        this.x = x;
        this.y = y;
        this.color = color;
        this.velocity = {
            x: (Math.random() - 0.5) * 5,
            y: (Math.random() - 0.5) * 5
        };
        this.alpha = 1;
        this.size = Math.random() * 3 + 1;
    }

    draw() {
        ctx.save();
        ctx.globalAlpha = this.alpha;
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
        ctx.fillStyle = this.color;
        ctx.fill();
        ctx.restore();
    }

    update() {
        this.x += this.velocity.x;
        this.y += this.velocity.y;
        this.alpha -= 0.01;
        this.size -= 0.01;
    }
}

// Функция для создания фейерверка
function createFireworks(x, y) {
    const color = `hsl(${Math.random() * 360}, 50%, 50%)`;
    for (let i = 0; i < 100; i++) {
        particles.push(new Particle(x, y, color));
    }
}

// Анимация фейерверка
function animate() {
    requestAnimationFrame(animate);
    ctx.fillStyle = 'rgba(0, 0, 0, 0.1)';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    particles.forEach((particle, index) => {
        if (particle.alpha <= 0) {
            particles.splice(index, 1);
        } else {
            particle.draw();
            particle.update();
        }
    });
}

// Обработчик клика по экрану
canvas.addEventListener('click', (e) => {
    createFireworks(e.clientX, e.clientY);
});

// Запуск анимации
animate();
