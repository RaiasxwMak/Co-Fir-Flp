import React from 'react'
import { Header } from 'antd/es/layout/layout'
import { Menu } from 'antd'
import { CaretDownOutlined } from '@ant-design/icons'
import styles from '../../styles/header.module.scss'


const header = () => {
  return (
    <div>
        <Header style={{ position: 'fixed', zIndex: 1, width: '100%', display: 'flex', justifyContent: 'space-between' , backgroundColor: 'rgb(37, 37, 39)'}}>
            <div className="container">
                <div className={styles.header__inner}>
                    <div className={styles.logo}>
                        <div className={styles.demoLogo}>
                        </div>
                        <div className={styles.logoText}>
                            <h1>Logo</h1>
                        </div>
                        
                        <div className={styles.logoDown}>
                            <CaretDownOutlined style={{fontSize: '10px'}}/>
                        </div>
                            
                    </div>
                    <Menu  mode="horizontal" theme='dark' defaultSelectedKeys={['2']} className={styles.menu}>
                        <Menu.Item key="1">Home</Menu.Item>
                        <Menu.Item key="2">About</Menu.Item>
                        <Menu.Item key="3">Services</Menu.Item>
                        <Menu.Item key="3">Portfolio</Menu.Item>
                        <Menu.Item key="3">Contact</Menu.Item>

                    </Menu>
                </div>
                
            </div>
        </Header>
        
    </div>
  )
}

export default header