
import Header from './layout/header/Header'
import './App.css'

function App() {

  

  return (
    <>
      <Header/>
    </>
  )
}

export default App
