import React, { useState, useEffect } from 'react'
import style from './Timer.module.css'
import Settings from '../settings/Settings';

function Timer({ pomodoroTime: defaultPomodoroTime, breakTime: defaultBreakTime }) {
  const [pomodoroTime, setPomodoroTime] = useState(defaultPomodoroTime);
  const [breakTime, setBreakTime] = useState(defaultBreakTime);
  const [time, setTime] = useState(pomodoroTime * 60);
  const [isActive, setIsActive] = useState(false);
  const [isBreak, setIsBreak] = useState(false);
  const [currentTime, setCurrentTime] = useState(new Date());
  const [showSettings, setShowSettings] = useState(false);

  useEffect(() => {
    let interval = null;
    if (isActive) {
      interval = setInterval(() => {
        setTime((prevTime) => {
          if (prevTime === 0) {
            setIsBreak(!isBreak);
            return isBreak ? pomodoroTime * 60 : breakTime * 60;
          }
          return prevTime - 1;
        });
      }, 1000);
    } else if (!isActive && time !== 0) {
      clearInterval(interval);
    }
    return () => clearInterval(interval);
  }, [isActive, time, isBreak, pomodoroTime, breakTime]);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    setTime(pomodoroTime * 60);
    setIsBreak(false);
    setIsActive(false);
  }, [pomodoroTime]);

  const formatTime = (time) => {
    const minutes = String(Math.floor(time / 60)).padStart(2, '0');
    const seconds = String(time % 60).padStart(2, '0');
    return `${minutes}:${seconds}`;
  };

  const handleStart = () => setIsActive(true);
  const handleStop = () => setIsActive(false);
  const handleReset = () => {
    setIsActive(false);
    setTime(pomodoroTime * 60);
    setIsBreak(false);
  };

  const [minutes, seconds] = formatTime(time).split(':');

  return (
    <div className={style.container}>
      <div className={style.currentTime}>
        {currentTime.toLocaleTimeString()}
      </div>
      
      <div className={style.timerContainer}>
        <div className={style.timer}>
          <div className={style.flipCard}>
            <div className={style.top} data-value={minutes[0]}>{minutes[0]}</div>
          </div>
          <div className={style.flipCard}>
            <div className={style.top} data-value={minutes[1]}>{minutes[1]}</div>
          </div>
          <div className={style.separator}>:</div>
          <div className={style.flipCard}>
            <div className={style.top} data-value={seconds[0]}>{seconds[0]}</div>
          </div>
          <div className={style.flipCard}>
            <div className={style.top} data-value={seconds[1]}>{seconds[1]}</div>
          </div>
        </div>
        
        <div className={style.status}>
          {isBreak ? 'Перерыв' : 'Работа'}
        </div>
        
        <div className={style.buttons}>
          <button onClick={handleStart}>▶</button>
          <button onClick={handleStop}>⏹</button>
          <button onClick={handleReset}>↺</button>
          <button onClick={() => setShowSettings(!showSettings)}>⚙</button>
        </div>
      </div>
      
      {showSettings && (
        <Settings 
          pomodoroTime={pomodoroTime}
          breakTime={breakTime}
          setPomodoroTime={setPomodoroTime}
          setBreakTime={setBreakTime}
        />
      )}
    </div>
  )
}

export default Timer