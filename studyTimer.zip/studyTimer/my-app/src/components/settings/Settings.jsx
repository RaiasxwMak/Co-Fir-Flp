import React, { useState } from 'react';
import styles from './Settings.module.css';

function Settings({ pomodoroTime, breakTime, setPomodoroTime, setBreakTime }) {
  const [newPomodoroTime, setNewPomodoroTime] = useState(pomodoroTime);
  const [newBreakTime, setNewBreakTime] = useState(breakTime);

  const handleSubmit = (e) => {
    e.preventDefault();
    

    if (newPomodoroTime <= 0 || newBreakTime <= 0) {
      alert('Время должно быть больше 0 минут');
      return;
    }
    
    setPomodoroTime(newPomodoroTime);
    setBreakTime(newBreakTime);
  };

  return (
    <div className={styles.settings}>
      <h2>Настройки</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label>
            Время работы (минуты):
            <input
              type="number"
              min="1"
              value={newPomodoroTime}
              onChange={(e) => setNewPomodoroTime(Math.max(1, Number(e.target.value)))}
            />
          </label>
        </div>
        <div>
          <label>
            Время перерыва (минуты):
            <input
              type="number"
              min="1"
              value={newBreakTime}
              onChange={(e) => setNewBreakTime(Math.max(1, Number(e.target.value)))}
            />
          </label>
        </div>
        <button type="submit">Сохранить</button>
      </form>
    </div>
  );
}

export default Settings;