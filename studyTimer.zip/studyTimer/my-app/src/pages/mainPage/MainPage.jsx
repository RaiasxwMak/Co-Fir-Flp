import React, { useState } from 'react'
import Timer from '../../components/timer/Timer'
import Settings from '../../components/settings/Settings'

function MainPage() {
  const [pomodoroTime, setPomodoroTime] = useState(25); 
  const [breakTime, setBreakTime] = useState(5); 

  return (
    <div>
        <Timer pomodoroTime={pomodoroTime} breakTime={breakTime} />
        <Settings 
          pomodoroTime={pomodoroTime} 
          breakTime={breakTime} 
          setPomodoroTime={setPomodoroTime} 
          setBreakTime={setBreakTime} 
        />
    </div>
  )
}

export default MainPage