import React from 'react'
import styles from './Header.module.css'
function Header() {

  return (
    <div>
        <div className={styles.header}>
            <div className="container">
                <div className={styles.logo}>
                    <div>
                        <img className={styles.logoImg} src="https://www.docplanner.com/img/logo-default-group-en.svg?v=1" alt="Docplanner Group" />
                    </div>
                    <button className={styles.logoBtn}>&#9660;</button>
                </div>
            </div>
        </div>
    </div>
  )
}

export default Header