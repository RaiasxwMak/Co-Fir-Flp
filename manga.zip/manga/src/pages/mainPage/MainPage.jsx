import React from 'react'
import Header from '../../componets/header/Header'

function MainPage() {
  return (
    <div>
        <Header/>
    </div>
  )
}

export default MainPage